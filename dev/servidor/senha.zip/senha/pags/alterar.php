<script type="text/javascript">
	function validacao() {
	if(document.form.senha.value=="")
	{
	alert("Por favor informe a senha.");
	document.form.senha.focus();
	return false;
	}
	}
	</script>
<form method="POST" onsubmit="return validacao();">
	<h4>INSIRA A SUA NOVA SENHA</h4>
	<hr>
	<label>Digite sua nova senha - mínimo 6 caracteres</label>
	<input type="password" name="senha" class="form-control" required minlength="6" placeholder="Senha com no mínimo 6 caracteres" ><br>

	<input type="submit" value="Efetuar Alterações" class="btn btn-outline-success btn-lg btn-block">
	<input type="hidden" name="env" value="upd">
</form>
<?php verifica_rash($con, $_GET['rash']);?>