<?php
	define("sitedir", "http://www.infolemmis.com/dev/senha/", TRUE);
?>