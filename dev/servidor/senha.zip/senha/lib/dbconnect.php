<?php
header('Content-Type: text/html; charset=utf-8');
$host = "localhost";
$user = "u852514288_test";
$pass = "P)d@sejaca";
$banco = "u852514288_test";
$con = new mysqli($host, $user, $pass, $banco);
	if(mysqli_connect_errno()){
		exit("Erro ao conectar-se ao banco de dados: ".mysqli_connect_error());
	}
mysqli_set_charset( $mysqli, 'utf8');
?>

