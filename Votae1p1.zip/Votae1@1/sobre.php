<!DOCTYPE HTML>
<html lang="pt-BR">
<head>
<title>Votae: Acesso
</title>
<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">     
<link rel="icon" type="image/jpg" href="img/icone_barra.jpg">
<!-- jQuery (necessario para os plugins Javascript do Bootstrap) -->
  <script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-----  bootstrap ------>

</head>
<!-------- inicia pagina-------------->
<body>

<div class="container">


<h1>Sobre</h1>
<p>Versão 1.0.1 RC</p>

<p>Esse sistema atende a entidades que desejam fazer consultas púbicas ou eleições eletrônicas.
</p>
<p>As eleições ou consultas públicas podem serem feitas através de votação criptografada, garantindo total sigilo do voto.</p>
Limitações 10 chapas

<input type="button" name="cancela" value="Voltar" onclick="window.location.href='index.php'"/>
</body>
</div>
</html>

