acessorio

votantes é usario criptigrafa
usereleicao autorizado votar.