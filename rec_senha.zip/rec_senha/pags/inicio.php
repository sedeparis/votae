<form method="POST">
	<label></label>
	<input type="text" class="form-control"><br>

	<label></label>
	<input type="password" class="form-control"><br>

	<input type="submit" value="Entrar" class="btn btn-primary btn-lg btn-block">
	<p align="right"><a href="?pagina=recuperar">Esqueceu a senha? Recupere já!</a></p>
</form>