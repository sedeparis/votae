<?php
	define("sitedir", "http://localhost/site", TRUE);
?>