<?php
	include_once("dbconnect.php");
	include_once("settings.php");
	include_once("functions.php");
?>