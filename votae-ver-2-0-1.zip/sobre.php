<!DOCTYPE HTML>
<html lang="pt-BR">
<head>
<title>Votae: Acesso
</title>
<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">     
<link rel="icon" type="image/jpg" href="img/icone_barra.jpg">
<!-- jQuery (necessario para os plugins Javascript do Bootstrap) -->
  <script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-----  bootstrap ------>

</head>
<!-------- inicia pagina-------------->
<body>

<div class="container">


<h1>Sobre</h1>
<p>Versão 2.0.1 RC</p>

<p>Esse sistema atende a entidades que desejam fazer consultas púbicas ou eleições eletrônicas.
</p>
<p>As eleições ou consultas públicas podem serem feitas através de votação criptografada, garantindo total sigilo do voto.</p>
Limitações 10 chapas.

<p>Licença</p>
<p>The MIT License (MIT)</p>

<p>Copyright (c) [2020] [Sedenir Marcos Deparis]</p>

<p>Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:</p>

<p>The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.</p>

<p>THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.</p>

        
          

<input type="button" name="cancela" value="Voltar" onclick="window.location.href='index.php'"/>
</body>
</div>
</html>

