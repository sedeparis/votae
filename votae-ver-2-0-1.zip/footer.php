<footer>
		<div class="container">
			<div class="row">
			<div class="col-lg-10 col-lg-offset-1 text-center">
			<h4><strong>Votae</strong>
			</h4>
			<p>R. Pedro Rigotti, 03 - Dourados - MS - 79.810-120 - Brasil
			<br></p>
			<ul class="list-unstyled">
			<li><i class="fa fa-phone fa-fw"></i> fone: 67 99647 0404 </li>
			<li><i class="fa fa-envelope-o fa-fw"></i> <a href="infolemmis@gmail.com">infolemmis@gmail.com</a>
			</li>
			</ul>
			<hr class="small">
			<p class="text-muted">Copyright Lemmis 2020
			<img src="img/lemmisp.png"></p>
			</div>
			</div>
		</div>
</footer>