		<div class="container">
				<div class="row">
				<div class="col-lg-12 text-center">
				<h2>Votação eletrônica.</h2>
				<p class="lead">Eleições, assembléias, pesquisas e consultas públicas.</p>
				<img src="../../img/logop.jpg">
				</div>
				</div>
				<!-- /.row -->
		</div>
			<!-- /.container -->