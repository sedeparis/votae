<?php
	require_once ("../../session.php");
include ("../../conecta_banco.php");
?>
<!DOCTYPE html>
<html lang="pt_br">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>VOTAe</title>
	<!-- Bootstrap Core CSS -->
	<link href="../../css/bootstrap.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="../css/stylish-portfolio.css" rel="stylesheet">
	<!-- Custom Fonts -->
	<link rel="icon" type="image/jpg" href="../../img/icone_barra.jpg">
</head>
<body>
	<section id="about" class="about">
		<?php 
			include_once "about.php" ; 
		?>
	</section>
		<!-- Services -->
		<!-- The circle icons use Font Awesome's stacked icon classes. For more information, visit http://fontawesome.io/examples/ -->
	<section id="services" class="services bg-primary-b">
		<div class="container">
			<div class="row text-center">
				<div class="col-lg-10 col-lg-offset-1">
					<div class="row">
						<div class="container">
						<?php 
						echo	$nomec= $_POST['nomec'];
						echo '<br>';
						echo	$ide= $_POST['ide'];
						echo '<br>';
						echo	$iduser= MD5($_POST['iduser']);
						echo '<br>';
						echo	$voto=$_POST['voto'];
						echo '<br>';
						if (  empty( $_POST['voto'] ) ) {
									$voto = '9999';
									}
									//informa usuario
									echo '<p><span class="colorblue">
									Seu voto foi computado como:' . $voto.' </span></p>' ;
									
										//update tabela votacao
										
							$sql =("UPDATE evs SET pseudo= '$nomec', voto='$voto' WHERE ide = '$ide' AND (iduser= '$iduser') AND voto = 0 ");
							$resultado = mysqli_query ($mysqli, $sql) or die(mysqli_error($mysqli));
							{echo "Alterado com sucesso!";}
							
							?>

								<?php
								echo "<meta HTTP-EQUIV='refresh' CONTENT='6;URL=../../painel.php'>";
								?>
						</div>
					</div>
					<!-- /.row (nested) -->
				</div>
				<!-- /.col-lg-10 -->
			</div>
			<!-- /.row -->
		</div>
		<!-- /.container -->
	</section>
	<!-- Footer -->
	<footer>
		<?php include_once "footer.php" ;?>
	</footer>
	<!-- jQuery -->
	<script src="js/jquery.js"></script>
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Custom Theme JavaScript -->
</body>
</html>