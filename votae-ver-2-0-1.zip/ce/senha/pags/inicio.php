<form method="POST">
	<input type="button" name="cancela" value="Cancelar" onclick="window.location.href='../indexc.php'"/>
	<p align="right"><a href="?pagina=recuperar">Esqueceu a senha? Recupere já!</a></p>
</form>