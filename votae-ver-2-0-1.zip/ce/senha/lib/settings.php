<?php
	define("sitedir", "http://www.infolemmis.com/des/ce/rec_senha", TRUE);
?>
