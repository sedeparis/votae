﻿<?php
//header('Content-Type: text/html; charset=utf-8');
$host = "localhost";
$user = "root";
$pass = "";
$banco = "votae2";
$mysqli = new mysqli($host, $user, $pass, $banco);
mysqli_set_charset( $mysqli, 'utf8');
?>