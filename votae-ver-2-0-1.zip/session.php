<?php
session_start();
$_SESSION ["email"];
$_SESSION ["senha"];
echo "<br><br>";
echo "<div class='container'>";
echo "Voce está logado como: ";
echo $_SESSION['email'];
echo "</div>";

// Verifica se a sessão do usuário está vazia
if ( empty( $_SESSION['email'] ) && empty( $_SESSION['senha'] ) ) {
	// Ação a ser executada: mata o script e manda uma mensagem
	exit('Sessão terminada por inatividade, faça login novamente. ');
}
?>
